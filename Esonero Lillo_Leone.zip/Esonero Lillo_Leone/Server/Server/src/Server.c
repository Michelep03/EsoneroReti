/*
 ============================================================================
 Name        : Server.c
 Version	 : 1.0
 Description : Server that receives operator and numbers from a client and computes the results.
 Authors     : Lillo Michele Pio, Leone Francesca
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

#include <stdio.h>
#include <string.h>
#include "protocol.h"
#include "calculator.h"

//Prototypes
void clearwinsock();
void errorhandler(char *errorMessage);

int main() {

	#if defined WIN32

	// Initialize Winsock
	WSADATA wsa_data;
	double result = WSAStartup(MAKEWORD(2,2), &wsa_data);

	if (result != 0) {
		printf("Error at WSAStartup\n");
		return 0;
	}

	#endif


	//Initialize welcome socket
	int my_socket;
	my_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (my_socket < 0) {
		errorhandler("socket creation failed.\n");
		clearwinsock();
		return -1;
	}


	//Set connection settings
	struct sockaddr_in sad;
	memset(&sad, 0, sizeof(sad)); // check that extra bytes contain 0 sad.sin_family = AF_INET;
	sad.sin_family = AF_INET;
	sad.sin_addr.s_addr = inet_addr(PROTO_ADDR);
	sad.sin_port = htons(PROTO_PORT); // Converts values between the host and network byte order.

	if (bind(my_socket, (struct sockaddr*) &sad, sizeof(sad)) < 0) {
		errorhandler("bind failed.\n");
		closesocket(my_socket);
		clearwinsock();
		return -1;
	}

	//Listen
	if (listen(my_socket, QLEN) < 0) {
		errorhandler("listen failed.\n");
		closesocket(my_socket);
		clearwinsock();
		return -1;
	}


	//Accept new connection
	struct sockaddr_in cad;  // structure for the client address
	int client_socket;       // socket descriptor
	int client_len;          // client address size
	printf("Waiting for a client to connect...\n\n");
	while (1) {
		client_len = sizeof(cad); // set the client address size
		if ((client_socket = accept(my_socket, (struct sockaddr*) &cad, &client_len)) < 0) {
			errorhandler("accept failed.\n");
			// Close connection
			closesocket(client_socket);
			clearwinsock();
			return 0;
		}
		//system("cls");
		printf("Connection established with %s:%d\n", inet_ntoa(cad.sin_addr), ntohs(cad.sin_port));

		while (1) {
			//Get msg from client
			if ((recv(client_socket, msg, sizeof(msg), 0)) <= 0) {
				errorhandler("recv failed or connection closed prematurely\n");
				closesocket(client_socket);
				clearwinsock();
				return -1;
			}

			// If the operator is "equal", close the connection
			if (!strcmp("=", msg)) {
				break;
			}

			double res = compute(msg);// Calculate operation result
			sprintf(msg, "%g", res); // Prints the result and, if the result is a decimal, displays the decimal places of the result

			//Send result data to client
			if (send(client_socket, msg, sizeof(msg), 0) != sizeof(msg)) {
				errorhandler("send sent a different number of bytes than expected\n");
				closesocket(client_socket);
				clearwinsock();
				return -1;
			}

			strcpy(msg, "\0");// Reset Buffer
		}

		closesocket(client_socket);
	}

	clearwinsock();
	return 0;
}

void clearwinsock() {
	#if defined WIN32
	WSACleanup();
	#endif
}

void errorhandler(char *errorMessage) {
	printf("%s", errorMessage);
}

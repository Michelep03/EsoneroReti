/*
 ============================================================================
 Name        : Client.c
 Version	 : 1.0
 Description : Client asking for operator and numbers variables to send to connected server
 Authors     : Lillo Michele Pio, Leone Francesca
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

#include <stdio.h>
#include <string.h>
#include "protocol.h"

//Prototypes
void clearwinsock();
void errorhandler(char *errorMessage);

int main() {

#if defined WIN32

	// Initialize Winsock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2,2), &wsa_data);

	if (result != 0) {
		printf("Error at WSAStartup()\n");
		return 0;
	}

	#endif


	//Create client socket
	int c_socket;
	c_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (c_socket < 0) {
		errorhandler("socket creation failed.\n");
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}

	//Set connection settings
	struct sockaddr_in sad;
	memset(&sad, 0, sizeof(sad));
	sad.sin_family = AF_INET;
	sad.sin_addr.s_addr = inet_addr(PROTO_ADDR); // Server address
	sad.sin_port = htons(PROTO_PORT); // Server port
	//Connection
	if (connect(c_socket, (struct sockaddr*) &sad, sizeof(sad)) < 0) {
		errorhandler("Failed to connect.\n");
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}

	printf("%s", "Connected to Server.\n\n");

	while (1) {
		//Get data from user
			printf("%s", "Enter operator(+, -, x, /) and two numbers: ");
			scanf("%[^\n]s", msg);
			scanf("%*c"); // flush buffer

		//Send data to server
		if (send(c_socket, msg, sizeof(msg), 0) != sizeof(msg)) {
			errorhandler("send() sent a different number of bytes than expected");
			closesocket(c_socket);
			clearwinsock();
			return -1;
		}

		strcpy(msg, "\0");// Reset Buffer

		//Get reply from server
		if ((recv(c_socket, msg, sizeof(msg), 0)) <= 0) {
			errorhandler("recv() failed or connection closed prematurely");
			closesocket(c_socket);
			clearwinsock();
			return -1;
		}

		printf("%s\n", msg);// Print result
	}

	return 0;
}

void clearwinsock() {
	#if defined WIN32
	WSACleanup();
	#endif
}

void errorhandler(char *errorMessage) {
	printf("%s", errorMessage);
}

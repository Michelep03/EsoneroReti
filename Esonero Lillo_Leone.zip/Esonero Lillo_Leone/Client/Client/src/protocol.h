/*
 * protocol.h
 * Authors: Lillo Michele Pio, Leone Francesca
 */

#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#define PROTO_ADDR "127.0.0.1"
#define PROTO_PORT 60000
#define BUFFER_SIZE 20
#define QLEN 5

char msg[BUFFER_SIZE];

#endif /* PROTOCOL_H_ */

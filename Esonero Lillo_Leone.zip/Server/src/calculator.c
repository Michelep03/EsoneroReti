/*
 * calculator.c
 * Authors: Lillo Michele Pio, Leone Francesca
 */

#include "calculator.h"

#include <stdio.h>

int add(int x, int y) {
	return +(x + y);
}

int sub(int x, int y) {
	return x - y;
}

int mult(int x, int y) {
	return x * y;
}

double division(int x, int y) {
	return (double)x / (double)y;
}

double compute(char k[]) {

	int x, y;
	char op;

	//Extract the operation to be performed and the two integers
	sscanf(k, "%c %d %d", &op, &x, &y);

	switch (op) {
		case '+':
			return add(x, y);
		case '-':
			return sub(x, y);
		case 'x':
		case 'X':
			return mult(x, y);
		case '/':
			return division(x, y);
		default:
			return 0;
	}

}

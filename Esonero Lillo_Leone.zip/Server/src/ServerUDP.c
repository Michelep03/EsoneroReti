/*
 ============================================================================
 Name        : ServerUDP.c
 Author      : Lillo Michele, Leone Francesca
 Version     : 1.0
 Description : This C program is a UDP server that communicates with a client.
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#define closeSocket close
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "protocol.h"
#include "calculator.h"

//Prototypes
void clearWinsock();
void errorHandler(char *errorMessage);

int main(int argc, char *argv[]) {

	#if defined WIN32
		// Initialize Winsock
		WSADATA wsa_data;
		int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
		if (result != 0) {
			printf("Error at WSAStartup()\n");
			return 0;
		}
	#endif

	// Initialize welcome socket
    int my_socket;
    my_socket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (my_socket < 0) {
        errorHandler("socket creation failed.\n");
        clearWinsock();
        return -1;
    }

    // Set connection settings
    struct sockaddr_in sad;
    memset(&sad, 0, sizeof(sad)); // check that extra bytes contain 0 sad.sin_family = AF_INET;
    sad.sin_family = AF_INET;
    sad.sin_addr.s_addr = INADDR_ANY;  // Server IP address
    sad.sin_port = htons(PROTO_PORT);  // Server port

    // bind
    if (bind(my_socket, (struct sockaddr *) &sad, sizeof(sad)) < 0) {
        errorHandler("bind() failed.\n");
        closesocket(my_socket);
        clearWinsock();
        return -1;
    }


    //Set connection settings
    struct sockaddr_in cad;  // structure for the client address
    int client_len;          // client address size

    printf("Waiting for a client to connect...\n\n");
    while (1) {
        client_len = sizeof(cad);  // set the client address size

        //receive data from the client
        if(recvfrom(my_socket, msg, sizeof(msg), 0, (struct sockaddr *) &cad, &client_len) <= 0) {
			errorHandler("recvfrom() failed.\n");
			// Close connection
			closesocket(my_socket);
			clearWinsock();
			return 0;
		}
        printf("Connection established with %s:%d\n", inet_ntoa(cad.sin_addr), ntohs(cad.sin_port));

        // Display client information and requested operation
        printf("Request for operation '%s' from client %s, IP %s\n", msg, gethostbyaddr((const char *)&cad.sin_addr, sizeof(cad.sin_addr), AF_INET)->h_name, inet_ntoa(cad.sin_addr));

		// If the operator is "equal", close the connection
        while (strcmp("=", msg) != 0) {
			float res = compute(msg);// Calculate operation result
			sprintf(msg, "%g", res); // Prints the result and, if the result is a decimal, displays the decimal places of the result
			//Send result data to client
			if(sendto(my_socket, &res, sizeof(res), 0, (struct sockaddr *) &cad, sizeof(cad)) <= 0) {
				errorHandler("send sent a different number of bytes than expected\n");
				closesocket(my_socket);
				clearWinsock();
				return -1;
			}
			strcpy(msg, "\0");// Reset Buffer

			//Get msg from client
			if (recvfrom(my_socket, msg, sizeof(msg), 0, (struct sockaddr *) &cad, &client_len) <= 0) {
				printf("error");
				errorHandler("recvfrom() failed or connection closed prematurely\n");
				closesocket(my_socket);
				clearWinsock();
				return -1;
			}
			// Display client information and requested operation
			printf("Request for operation '%s' from client %s, IP %s\n", msg, gethostbyaddr((const char *)&cad.sin_addr, sizeof(cad.sin_addr), AF_INET)->h_name, inet_ntoa(cad.sin_addr));

        }
        printf("Connection closed");
    }
	// Close socket
	closesocket(my_socket);
    clearWinsock();
    return 0;
}

void clearWinsock() {
#if defined WIN32
    WSACleanup();
#endif
}

void errorHandler(char *errorMessage) {
    perror(errorMessage);
}

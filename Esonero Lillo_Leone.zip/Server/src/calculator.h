/*
 * calculator.h
 * Authors: Lillo Michele Pio, Leone Francesca
 */

#ifndef CALCULATOR_H_
#define CALCULATOR_H_

int add(int x, int y);
int sub(int x, int y);
int mult(int x, int y);
double division(int x, int y);
double compute(char k[]);

#endif /* CALCULATOR_H_ */

/*
 * protocol.h
 *
 *      Author: Lillo Michele, Leone Francesca
 */

#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#define PROTO_ADDR "127.0.0.1"
#define PROTO_PORT 56700
#define BUFFER_SIZE 255

char msg[BUFFER_SIZE];

#endif /* PROTOCOL_H_ */

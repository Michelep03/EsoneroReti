/*
 ============================================================================
 Name        : ClientUDP.c
 Author      : Lillo Michele, Leone Francesca
 Version     : 1.0
 Description : This C program is a UDP client that communicates with a server.
 ============================================================================
 */
#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "protocol.h"

//Prototypes
void clearWinsock();
void errorHandler(char *errorMessage);

int main(int argc, char *argv[]) {
	#if defined WIN32
		// Initialize Winsock
		WSADATA wsa_data;
		int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
		if (result != 0) {
			printf("Error at WSAStartup()\n");
			return 0;
		}
	#endif

    char serverName[]="srv.di.uniba.it";

    // create client socket
    int c_socket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP); // Use SOCK_DGRAM for UDP
    if(c_socket < 0) {
        errorHandler("socket creation failed.\n");
        closesocket(c_socket);
        clearWinsock();
        return -1;
    }

    // Get host information
    struct hostent *host = gethostbyname(serverName);
    if (host == NULL) {
        errorHandler("Error getting host");
        clearWinsock();
        return EXIT_FAILURE;
    }

    // Set connection settings
    struct sockaddr_in sad;
    memset(&sad, 0, sizeof(sad));
    sad.sin_family = AF_INET;
    sad.sin_addr.s_addr = inet_addr(PROTO_ADDR); // IP of the server
    sad.sin_port = htons(PROTO_PORT); // Server port

    printf("Server name: %s (IP: %s, port: %d)\n", serverName, inet_ntoa(*(struct in_addr*) host->h_addr), PROTO_PORT);

    while(1) {
    	//Get data from user
		printf("%s", "Enter operator(+, -, x, /) and two numbers: ");
		scanf("%[^\n]s", msg);
		scanf("%*c"); // flush buffer


		//Send data to server
		if(sendto(c_socket, msg, sizeof(msg), 0, (struct sockaddr*) &sad, sizeof(sad)) <= 0) {
			errorHandler("send() sent a different number of bytes than expected");
			closesocket(c_socket);
			clearWinsock();
			return -1;
		}

		if(strcmp("=", msg) == 0){
			break;
		}

        struct sockaddr_in server_address;
        int server_address_len = sizeof(server_address);

		//Get reply from server
        float res;
		if(recvfrom(c_socket, &res, sizeof(res), 0, (struct sockaddr*) &server_address, &server_address_len) <= 0) {
			errorHandler("recvfrom() failed or connection closed prematurely");

		}
		//Extract the operation to be performed and the two integers
		int x, y;
		char op;
		sscanf(msg, "%c %d %d", &op, &x, &y);
		// Print result
		printf("Received result from server %s, IP %s: %d%c%d = %g\n\n", gethostbyaddr((const char*)&server_address.sin_addr, sizeof(server_address.sin_addr), AF_INET)->h_name, inet_ntoa(server_address.sin_addr), x,op,y, res);

    }
    // Close socket
	closesocket(c_socket);
	clearWinsock();
    return 0;
}

void clearWinsock() {
#if defined WIN32
    WSACleanup();
#endif
}

void errorHandler(char *errorMessage) {
    printf("%s", errorMessage);
}
